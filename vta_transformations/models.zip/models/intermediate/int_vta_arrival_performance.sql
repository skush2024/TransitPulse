{{ config(materialized='view') }}

with realtime_arrivals as (

    select
        trip_id,
        route_id,
        current_stop_sequence as stop_sequence,
        min(ping_timestamp) as actual_arrival_timestamp,
        cast(min(ping_timestamp) as time) as actual_arrival_time
    from {{ ref('stg_vta_realtime') }}
    where trip_id is not null
      and route_id is not null
      and current_stop_sequence is not null
    group by 1, 2, 3

),

schedule as (

    select
        trip_id,
        stop_sequence,
        stop_id,
        scheduled_arrival_time
    from {{ ref('stg_vta_stop_times') }}
    where trip_id is not null
      and stop_sequence is not null
      and stop_id is not null
      and scheduled_arrival_time is not null

),

joined as (

    select
        r.trip_id,
        r.route_id,
        r.stop_sequence,
        r.actual_arrival_timestamp,
        r.actual_arrival_time,
        s.stop_id,
        s.scheduled_arrival_time,

        extract(
            epoch from (r.actual_arrival_time - s.scheduled_arrival_time)
        ) / 60.0 as delay_minutes

    from realtime_arrivals r
    inner join schedule s
        on r.trip_id = s.trip_id
        and r.stop_sequence = s.stop_sequence

),

headways as (

    select
        *,
        extract(
            epoch from (
                actual_arrival_timestamp - lag(actual_arrival_timestamp) over (
                    partition by route_id, stop_id
                    order by actual_arrival_timestamp
                )
            )
        ) / 60.0 as actual_headway_minutes
    from joined

),

stop_delay_iqr as (

    select
        stop_id,

        percentile_cont(0.75) within group (
            order by delay_minutes
        ) as delay_p75,

        percentile_cont(0.25) within group (
            order by delay_minutes
        ) as delay_p25,

        percentile_cont(0.75) within group (
            order by delay_minutes
        )
        -
        percentile_cont(0.25) within group (
            order by delay_minutes
        ) as stop_delay_iqr

    from headways
    where delay_minutes is not null
    group by stop_id

)

select
    h.trip_id,
    h.route_id,
    h.stop_sequence,
    h.actual_arrival_timestamp,
    h.actual_arrival_time,
    h.stop_id,
    h.scheduled_arrival_time,
    h.delay_minutes,
    h.actual_headway_minutes,
    i.stop_delay_iqr

from headways h
left join stop_delay_iqr i
    on h.stop_id = i.stop_id